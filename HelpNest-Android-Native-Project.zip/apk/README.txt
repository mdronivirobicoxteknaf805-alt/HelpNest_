HelpNest Release APK folder
Path: apk/app-release.apk
Generated automatically after running ./gradlew assembleRelease
