# HelpNest (HelpNest)
Tagline: মানুষের পাশে, মানবতার জন্য
Package: Com.HelpNest.HelpNest
Super Admin UID: yl5yzmtzFvT6OaWQ2jN2rtZd4VE3

## Build Release APK:
```bash
./gradlew assembleRelease
```
Generated APK location: apk/app-release.apk
